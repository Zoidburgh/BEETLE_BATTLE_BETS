========================================
       BEETLE BATTLE - SETUP
========================================

1. INSTALL PYTHON 3.12
   - Download from https://python.org/downloads
   - Check "Add Python to PATH" during install
   - Restart computer after install

   NOTE: If you already use Python for other projects,
   you can install 3.12 WITHOUT checking "Add to PATH".
   The game will still work.

2. EXTRACT THE ZIP
   - Right-click BeetleBattle.zip → Extract All

3. RUN INSTALL.BAT
   - Double-click INSTALL.bat
   - Wait for it to finish

4. START STEAM
   - Make sure Steam is running

5. RUN PLAY.BAT
   - Double-click PLAY.bat (1080p default)

   PERFORMANCE OPTIONS:
   - PLAY_720p.bat  - Best FPS (for 4K monitors/slower PCs)
   - PLAY_900p.bat  - Balanced quality/performance
   - PLAY.bat       - Full 1080p quality

========================================
         MULTIPLAYER
========================================

Player 1: Click "Host Game", share lobby ID
Player 2: Click "Join Game", paste lobby ID

========================================
         CONTROLS
========================================

ONLINE MULTIPLAYER:
  Move:      WASD
  Horn:      Arrow Keys

LOCAL 2-PLAYER:
  Blue:      TFGH to move, RY/VB for horn
  Red:       IJKL to move, UO/NM for horn

========================================
